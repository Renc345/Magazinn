﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using magazinn.Pages;
using magazinn.Classes;

namespace magazinn.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageMagazin.xaml
    /// </summary>
    public partial class PageMagazin : Page
    {
        public PageMagazin()
        {
            InitializeComponent();
            DGridMagazin.ItemsSource = MagazinEntities.GetContext().Products.ToList();
            var listMagazin = MagazinEntities.GetContext().Products.Select(x => x.Product).Distinct().ToList();
            CmbFiltrMagazin.Items.Add("Все товары");
            foreach (string productt in listMagazin)
            {
                CmbFiltrMagazin.Items.Add(productt);
            }

        }
        private void btnEdit_Click(object sender, RoutedEventArgs e)
        //Редактирование товаров
        {
            ClassFrame.frmObj.Navigate(new PageAddMagazin((sender as Button).DataContext as Products));
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        // Добавление товаров
        {
            ClassFrame.frmObj.Navigate(new PageAddMagazin(null)/*((Person)DGridUsers.SelectedItem)*/);
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            //Удаление нескольких товаров
            var personForRemoving = DGridMagazin.SelectedItems.Cast<Products>().ToList();
            if (MessageBox.Show($"Удалить {personForRemoving.Count()} пользователей?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    MagazinEntities.GetContext().Products.RemoveRange(personForRemoving);
                    MagazinEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    DGridMagazin.ItemsSource = MagazinEntities.GetContext().Products.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {//Динамиеское отображение добавленных или изменённых данных
            if (Visibility == Visibility.Visible)
            {
                MagazinEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridMagazin.ItemsSource = MagazinEntities.GetContext().Products.ToList();
            }
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            DGridMagazin.ItemsSource = MagazinEntities.GetContext().Products.ToList();
        }

        private void CmbFiltrMagazin_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string productt = CmbFiltrMagazin.SelectedValue.ToString();
            if (productt != "Все товары")
                DGridMagazin.ItemsSource = MagazinEntities.GetContext().Products.Where(x => x.Product == productt).ToList();
            else
                DGridMagazin.ItemsSource = MagazinEntities.GetContext().Products.ToList();
        }


        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DGridMagazin.ItemsSource = MagazinEntities.GetContext().Products.OrderBy(x => x.Product).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DGridMagazin.ItemsSource = MagazinEntities.GetContext().Products.OrderByDescending(x => x.Product).ToList();
        }



        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGridMagazin.ItemsSource = MagazinEntities.GetContext().Products.Where(x => x.Product.ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
        }

        private void MenuSaveToExcel_Click(object sender, RoutedEventArgs e)
        {
            
        }


        //private void BtnToList_Click(object sender, RoutedEventArgs e)
        //{
        //    ClassFrame.frmObj.Navigate(new PageListStudent());
        //}
    }
}

