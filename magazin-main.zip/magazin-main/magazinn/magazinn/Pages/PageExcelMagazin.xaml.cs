﻿//using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using magazinn.Classes;
using System;

namespace magazinn.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageExcelMagazin.xaml
    /// </summary>
    public partial class PageExcelMagazin : Page
    {
        public PageExcelMagazin()
        {
            InitializeComponent();
            var currentUser = MagazinEntities.GetContext().Products.ToList();
            LViewUser.ItemsSource = currentUser;
            DataContext = LViewUser;
        }
        private void BtnSaveToExcel_Click(object sender, RoutedEventArgs e)
        {
            var app = new Excel.Application();

            //книга 
            Excel.Workbook wb = app.Workbooks.Add();
            //лист
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int indexRows = 1;
            //ячейка
            worksheet.Cells[1][indexRows] = "Номер";
            worksheet.Cells[2][indexRows] = "Товар";
            worksheet.Cells[3][indexRows] = "Артикл товара";
            worksheet.Cells[4][indexRows] = "Цена";
            worksheet.Cells[5][indexRows] = "Количество";
            worksheet.Cells[6][indexRows] = "Ед.измерения";
            worksheet.Cells[7][indexRows] = "Скидка";
            worksheet.Cells[8][indexRows] = "Дата продажи";
            worksheet.Cells[9][indexRows] = "Категория";
            worksheet.Cells[10][indexRows] = "Компания";
            //список пользователей
            var printItems = MagazinEntities.GetContext().Products.ToList();
            //цикл по данным из таблицы
            foreach (var item in printItems)
            {
                worksheet.Cells[1][indexRows + 1] = indexRows;
                worksheet.Cells[2][indexRows + 1] = item.Product;
                worksheet.Cells[3][indexRows + 1] = item.ItemNumber.ToString();
                worksheet.Cells[4][indexRows + 1] = item.Price.ToString();
                worksheet.Cells[5][indexRows + 1] = item.Quantity.ToString();
                worksheet.Cells[6][indexRows + 1] = item.Measurement;
                worksheet.Cells[7][indexRows + 1] = item.Discount.ToString();
                worksheet.Cells[8][indexRows + 1] = item.DateSale.ToString();
                worksheet.Cells[9][indexRows + 1] = item.Category1.ProductCategory.ToString();
                worksheet.Cells[10][indexRows + 1] = item.Company1.CompanyName.ToString();
                indexRows++;
            }

            //показать Excel
            app.Visible = true;
        }

        private void BtnSaveToExcelTemplate_Click(object sender, RoutedEventArgs e)
        {
            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook wb = excelApp.Workbooks.Open($"{Directory.GetCurrentDirectory()}\\Shablon.xlsx");
            Excel.Worksheet ws = (Excel.Worksheet)wb.Worksheets[1];
            ws.Cells[1, 4] = "Магазин";
            ws.Cells[4, 1] = "Дата";
            DateTime date = new DateTime(2022, 1, 1, 18, 30, 10);
            ws.Cells[4, 2] = date.ToShortDateString();
            int indexRows = 6;
            //ячейка
            ws.Cells[1][indexRows] = "Номер";
            ws.Cells[2][indexRows] = "Товар";
            ws.Cells[3][indexRows] = "Артикл товара";
            ws.Cells[4][indexRows] = "Цена";
            ws.Cells[5][indexRows] = "Количество";
            ws.Cells[6][indexRows] = "Ед.измерения";
            ws.Cells[7][indexRows] = "Скидка";
            ws.Cells[8][indexRows] = "Дата продажи";
            ws.Cells[9][indexRows] = "Категория";
            ws.Cells[10][indexRows] = "Компания";

            //список пользователей из таблицы после фильтрации и поиска
            var printItems = LViewUser.Items;
            //цикл по данным из списка для печати
            foreach (Products item in printItems)
            {
                ws.Cells[1][indexRows + 1] = indexRows;
                ws.Cells[2][indexRows + 1] = item.Product;
                ws.Cells[3][indexRows + 1].Value = item.ItemNumber.ToString();
                ws.Cells[4][indexRows + 1].Value = item.Price.ToString();
                ws.Cells[5][indexRows + 1].Value = item.Quantity.ToString();
                ws.Cells[6][indexRows + 1] = item.Measurement;
                ws.Cells[7][indexRows + 1].Value = item.Discount.ToString();
                ws.Cells[8][indexRows + 1].Value = item.DateSale.ToString();
                ws.Cells[9][indexRows + 1].Value = item.Category1.ProductCategory.ToString();
                ws.Cells[10][indexRows + 1].Value = item.Company1.CompanyName.ToString();

                indexRows++;
            }
            ws.Cells[indexRows + 2, 3] = "Подпись";
            ws.Cells[indexRows + 2, 4] = "Стародубцев.М.С";
            excelApp.Visible = true;
        }

        private void Glav_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageGlavnai());
        }

        private void LViewUser_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
