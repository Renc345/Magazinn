﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using magazinn.Classes;

namespace magazinn.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddCategorei.xaml
    /// </summary>
    public partial class PageAddCategorei : Page
    {
        private Category _currentperson = new Category(); //экземпляр добавляемого пользователя
        public PageAddCategorei(Category selectedCategorei)
        {
            InitializeComponent();
            if (selectedCategorei != null)
                _currentperson = selectedCategorei;
            DataContext = _currentperson;
        }
        private void Savebtn_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();// Объект для сообщение об ошибке
            //проверка полей объекта
            if (string.IsNullOrWhiteSpace(_currentperson.ProductCategory))
                error.AppendLine("Укажите название категории");
            if (error.Length > 0)

            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentperson.IDcategory == 0)
                MagazinEntities.GetContext().Category.Add(_currentperson);//Добавить в контекст
            try
            {

                MagazinEntities.GetContext().SaveChanges();// Сохранить изменения
                MessageBox.Show("Данные сохраненны");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
